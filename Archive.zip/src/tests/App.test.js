import React from 'react';
import ReactDOM from 'react-dom';

import App from '../App';
import {Helper} from '../components/Helper'

//Généré automatiquement
it('renders works', () => {
    const div = document.createElement('div');
    ReactDOM.render(<App />, div);
});