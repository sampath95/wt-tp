import React from 'react';
import ReactDOM from 'react-dom';

import Choice from '../components/Choice';
import {Helper} from '../components/Helper';

it('adds a choice to the list', () => {
    const initialChoices = [
        {id: 1, content: "Chinese", votes: 3},
        {id: 2, content: "English", votes: 2}
    ];

    const newChoices = Helper.addChoiceToList(initialChoices, "French");
  
    const expectedChoices = [
      ...initialChoices,
      newChoices[2]
    ];
  
    expect(newChoices).toEqual(expectedChoices);
  });

it('add a choice with helper', () => {

    const initialChoices = [
        {id: 1, content: "Chinese", votes: 3},
        {id: 2, content: "English", votes: 2}
    ];

    const expectedChoices = [...initialChoices ];

    Helper.addChoiceToList(initialChoices, "French");

    expect(initialChoices).toEqual(expectedChoices);
  });