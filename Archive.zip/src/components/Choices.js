import React, { Component } from 'react';

import Choice from './Choice';

class Choices extends Component {
    render() {
      	return (
        	this.props.choices.map(t => <Choice key={t.id} {...t} Update={this.props.Update} />) 
      	)
    }
}
  
export default Choices;
