import React, { Component } from 'react';

import AddChoice from './AddChoice';
import Choices from './Choices';
import {Helper} from './Helper';

import Paper from 'material-ui/Paper';
import {Card, CardHeader} from 'material-ui/Card';
import {Table, TableBody, TableHeader, TableHeaderColumn, TableRow,} from 'material-ui/Table';

const GivenChoices = [
  	{
		id: 1,
	    content: "Chinese",
    	votes: 0
	},

  	{
		id: 2,
    	content: "English",
    	votes: 0
	},

    {
		id: 3,
      	content: "French",
      	votes: 0
	},

    {
		id: 4,
      	content: "Spanish",
      	votes: 0
	},

	{
		id: 5,
      	content: "Russian",
      	votes: 0
	},

	{
		id: 6,
      	content: "Arab",
      	votes: 0
	}
];

class SurveyMain extends Component {
    constructor() {
      	super();
      	this.state = {choices: GivenChoices}
	}
	
    render() {
      	return (
			<Paper className="Language Survey">
			<br />

            <Card className="Header Part">
				<CardHeader className="Header" title="What language can you speak?"
				subtitle="Choose the answers that fit you, or add a new one." />
            </Card>

			<Card className="Main Part">
                <CardHeader className="Header" title="Vote Zone" />

				<Table>
					<TableHeader>
                        <TableRow>
                          	<TableHeaderColumn className="column">Name</TableHeaderColumn>
                          	<TableHeaderColumn className="column">Votes</TableHeaderColumn>
                        </TableRow>
                    </TableHeader>

                    <TableBody>
                        <Choices choices={this.state.choices} />
                    </TableBody>        
                </Table>
                    
                <AddChoice addChoice={this.addChoicesToState} />
            </Card>
        	</Paper>
    	);
	}

    addChoicesToState = (name) => {
      	var newState2 = Helper.addChoiceToList(this.state.choices, name);
      	this.setState({choices: newState2});
    };
}

export default SurveyMain;

