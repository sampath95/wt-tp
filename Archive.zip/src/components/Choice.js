import React from 'react';
import PropTypes from 'prop-types';

import SurveyVotes from './SurveyVotes';

import {TableRow, TableRowColumn} from 'material-ui/Table';

const Choice = (props) => (
    <TableRow>
        <TableRowColumn className="column"> 
            {props.content}
        </TableRowColumn>
        <TableRowColumn className="column">
            <SurveyVotes id={props.id} name={props.content} Update={props.Update}/>
        </TableRowColumn>
    </TableRow>
);

Choice.propTypes = {
    id: PropTypes.number.isRequired,
    content: PropTypes.string
}

export default Choice;
