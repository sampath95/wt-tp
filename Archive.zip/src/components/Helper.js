const Helper = {
    addChoiceToList: (choiceList, newChoice) => 
    {
        const newChoiceList = [...choiceList];

        newChoiceList.push({
            id: Math.floor((Math.random() * 1000) + 1),
            content: newChoice,
            votes: 0
        });
        
        return newChoiceList;
    }
}

export {Helper};
