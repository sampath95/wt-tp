import React, { Component } from 'react';
import PropTypes from 'prop-types';

class AddChoice extends Component {
	constructor() {
    	super();
    	this.state = {NewChoice: ''}
  	}
render() {
    return (
        <div>
          	<input type="text" value={this.state.NewChoice} onChange={this.UpdateDetail} />
          	<input type="button" value="Add Choice" onClick={this.addChoice} />
        </div>
      	);
    }

    UpdateDetail = (t) => (
        this.setState({NewChoice: t.target.value})
    )

    addChoice = () => {
        if(this.state.NewChoice !== '') {
          	this.props.addChoice(this.state.NewChoice);
        }
        this.setState({NewChoice: ''});
    }
}


AddChoice.propTypes = {
  	NewChoice : PropTypes.string
}

export default AddChoice;
