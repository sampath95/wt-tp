import React from 'react';
import PropTypes from 'prop-types';

const SurveyVotes = (props) => (
    <div className="vote part">
		<input type="number" min="0" defaultValue="0" onChange={props.Update} />
    </div>
);

SurveyVotes.propTypes = {
  	id: PropTypes.number.isRequired,
  	name: PropTypes.string
}
 
export default SurveyVotes;
